HESHAM & SARA — WEDDING INVITATION TEMPLATE

Open index.html in a browser to preview.

To personalize:
1. Open index.html in a text editor.
2. In the script near the bottom, set:
   - weddingDate = "YYYY-MM-DDTHH:MM:SS+02:00"
   - mapLinks.ceremony and mapLinks.reception
   - rsvpWhatsApp = country code + phone number, digits only
   - musicFile = "music.mp3" (place a music file beside index.html)
3. Update the visible venue/date/time text in the two detail cards.
4. Upload index.html (and optional music.mp3) to GitHub Pages or another static hosting provider.

This is a responsive first draft. Send the actual wedding date, venue, time, Google Maps link, and RSVP number to customize it fully.
